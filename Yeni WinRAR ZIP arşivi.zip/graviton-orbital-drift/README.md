# Graviton: Orbital Drift

**Graviton: Orbital Drift**, uzayın derinliklerinde geçen, yerçekimi sapanı mekaniğine dayalı, yüksek tempolu ve göz alıcı neon estetiğine sahip benzersiz bir HTML5 mobil oyunudur. Tek parmakla (dokun ve basılı tut / bırak) oynanış yapısı sayesinde özellikle mobil cihazlarda ve **iPhone 17 Pro Max** gibi yüksek çözünürlüklü/çentikli ekranlarda kusursuz çalışacak şekilde tasarlanmıştır.

## 🚀 Oyunu Yerel Olarak Çalıştırma

Oyunu bilgisayarınızda veya telefonunuzda test etmek için ek bir kuruluma gerek yoktur:
1. `graviton-orbital-drift` klasörünün içindeki **`index.html`** dosyasına çift tıklayarak herhangi bir tarayıcıda (Chrome, Safari, Edge vb.) oyunu anında başlatabilirsiniz.
2. Telefonunuzda denemek için tarayıcınızın geliştirici araçlarından mobil görünümü simüle edebilir ya da yerel ağınız üzerinden telefonunuzdan bilgisayarınızın IP adresine bağlanabilirsiniz.

---

## 🌐 GitHub Pages Üzerinde Yayınlama Adımları (Ücretsiz Hosting)

Oyunu internette yayınlayıp iPhone'unuzdan veya arkadaşlarınızla paylaşmak için aşağıdaki adımları takip edebilirsiniz:

### 1. Adım: GitHub Hesabı ve Depo (Repository) Oluşturma
1. [GitHub](https://github.com) hesabınıza giriş yapın (hesabınız yoksa ücretsiz üye olun).
2. Sağ üstteki **`+`** simgesine tıklayıp **`New repository`** (Yeni Depo) seçeneğini seçin.
3. **Repository name** kısmına oyunun adını yazın (örneğin: `graviton-orbital-drift`).
4. Deponun **`Public`** (Açık) olduğundan emin olun.
5. Alt kısımdaki **`Create repository`** butonuna tıklayarak depoyu oluşturun.

### 2. Adım: Kodları GitHub'a Yükleme
Git yüklü değilse en kolay yöntem doğrudan tarayıcı üzerinden yüklemektir:
1. Oluşturduğunuz boş deponun sayfasında orta kısımda yer alan **`uploading an existing file`** (mevcut bir dosyayı yükle) bağlantısına tıklayın.
2. Masaüstünüzdeki `graviton-orbital-drift` klasörünün içindeki **tüm dosyaları** (`index.html`, `style.css`, `game.js` ve `README.md`) sürükleyip tarayıcıdaki kutucuğa bırakın.
3. Sayfanın altındaki **`Commit changes`** (Değişiklikleri kaydet) butonuna tıklayın.

*(Alternatif olarak Git terminali kullanıyorsanız klasör içinde `git init`, `git add .`, `git commit -m "initial commit"`, `git remote add origin <depo_adresi>` ve `git push -u origin main` komutlarını çalıştırabilirsiniz).*

### 3. Adım: GitHub Pages'i Aktif Etme
1. GitHub deposundaki üst menüden **`Settings`** (Ayarlar) sekmesine gidin.
2. Sol menüdeki **`Pages`** seçeneğine tıklayın.
3. **Build and deployment** başlığı altındaki **Branch** ayarında **`None`** yazan yeri **`main`** (veya `master`) olarak değiştirin. Klasör olarak da **`/ (root)`** seçeneğini bırakın.
4. **`Save`** (Kaydet) butonuna tıklayın.

### 🎉 Oyununuz Yayında!
Yaklaşık 1-2 dakika içinde sayfanın üst kısmında size özel bir bağlantı belirecektir:
`https://<kullanici-adiniz>.github.io/graviton-orbital-drift/`

Bu bağlantıyı iPhone'unuza gönderip Safari veya Chrome üzerinden açarak oyunu hemen oynamaya başlayabilirsiniz.

---

## 🎮 Oynanış Mekanikleri

- **Yörüngeye Girme**: Ekrana **dokunun ve basılı tutun**. En yakındaki yerçekimi merkezine kilitlenip etrafında dönmeye başlayacaksınız.
- **Fırlatma (Sapan Etkisi)**: Parmağınızı ekrandan **çekin**. Yerçekiminden kurtularak teğet doğrultusunda hızla ileri fırlayacaksınız.
- **Hedef**: Aşağı düşmeden veya kırmızı engellere çarpmadan olabildiğince yukarı tırmanmak.
- **Altın Kristaller**: Size ekstra +50 puan kazandırır ve harika ses efektlerini tetikler!
- **Duvarlardan Sekme**: Sağ veya sol sınıra çarptığınızda hızınızı koruyarak kıvılcım efektleriyle duvardan sekerisiniz.

## 🛠️ Teknik Özellikler

- **Web Audio API**: Dışarıdan hiç ses dosyası indirmeden oyun içindeki tüm retro ses efektlerini (yörünge kilidi, fırlama, patlama, kristal toplama) tarayıcının kendi ses motoruyla sentezler.
- **Dinamik Çözünürlük ve Safe Area (Güvenli Alan)**: iPhone 17 Pro Max gibi ekranın üstünde Dinamik Ada (Dynamic Island) ve altında home çizgisi barındıran cihazlarda HUD elemanlarının çentikle çakışmaması için CSS `env(safe-area-inset-*)` kodlaması entegre edilmiştir.
- **Anti-Aliasing ve Retina Desteği**: Yüksek yoğunluklu ekranlar (Retina vb.) için canvas çizimleri pikselleşme olmadan cam gibi net (pixelRatio uyumlu) render edilir.
